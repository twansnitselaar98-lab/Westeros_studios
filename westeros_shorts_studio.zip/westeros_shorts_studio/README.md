# Westeros Shorts Studio — gratis starter

Een statische, browsergebaseerde tool om een YouTube Shorts-productiebriefing te maken voor Game of Thrones / House of the Dragon lore.

## Wat zit erin?

- Onderwerp, universum, duur, vertelvorm en beeldstijl kiezen.
- Een uitgebreide prompt maken die je naar een AI-chat kunt kopiëren.
- Je definitieve voice-over plakken.
- Een eenvoudig scèneplan en beeldprompts genereren.
- Ondertitels als `.srt` maken en downloaden.
- Metadata/hashtags en een projectbestand exporteren.
- Geen account, eigen backend, API-sleutels of externe JavaScript-bibliotheken.

## Wat zit er nog niet in?

Deze starter genereert niet zelfstandig AI-tekst, afbeeldingen, spraak of een MP4 en uploadt niets naar YouTube. De prompt kan naar een AI-dienst gekopieerd worden, maar dan gelden de voorwaarden en privacyregels van die dienst. De scène-indeling en SRT-timing zijn schattingen: controleer ze met je uiteindelijke voice-over.

## Veiligheidsmodel

- De app is statisch en voert alle logica in de browser uit.
- Er worden geen invoervelden verstuurd naar een door dit project beheerde server.
- Er zijn geen wachtwoorden, API-sleutels, analytics of externe scripts.
- Er is geen automatische YouTube OAuth-koppeling.
- Dit is geen garantie tegen alle aanvallen: gebruik een actuele browser en publiceer alleen via de officiële GitHub Pages-site van je eigen repository.

## Publiceren met alleen een iPhone

1. Open Safari en ga naar https://github.com/.
2. Maak een account aan of log in.
3. Maak een **private repository** aan, bijvoorbeeld `westeros-shorts-studio`.
4. Voeg `index.html`, `styles.css` en `app.js` toe via **Add file → Create new file**. Plak de inhoud uit elk bestand en commit de wijziging.
5. Open de repository **Settings → Pages**.
6. Kies bij Build and deployment voor **Deploy from a branch**; kies `main` en `/ (root)`, en sla op.
7. Wacht tot GitHub Pages de site heeft gepubliceerd. De URL staat op de Pages-instellingenpagina, meestal in de vorm `https://JOUW-GITHUB-NAAM.github.io/westeros-shorts-studio/`.
8. Open die URL in Safari. Gebruik de deelknop → **Zet op beginscherm** om een app-achtig icoon te maken.

### Belangrijk over een private repository

GitHub Pages op een gratis account publiceert de website doorgaans publiek, ook als de repository zelf privé is niet voor alle accountsoorten beschikbaar. Ga er daarom van uit dat de **sitebestanden publiek zichtbaar kunnen zijn**. Dat is prima voor deze starter omdat er geen geheimen of persoonlijke gegevens in de code staan. Zet nooit wachtwoorden, tokens of API-sleutels in de bestanden.

## Testen op iPhone

- Vul een onderwerp in en druk op **Maak mijn productiebriefing**.
- Kopieer de prompt naar ChatGPT of een andere AI-dienst.
- Plak de voice-over terug in de app.
- Maak een scèneplan en ondertitels.
- Download de `.srt` en projectbestanden via Safari.

## Volgende stap

Voor een echte MP4-video en automatische upload is een backend of externe productiedienst nodig. Bouw dat pas als een aparte fase met authenticatie, strikte API-sleutelopslag, quota en handmatige goedkeuring vóór publicatie.

(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const form = $("video-form");
  const results = $("results");
  let project = {};

  const styleNames = {
    cinematic: "donker, cinematografisch, realistisch, dramatisch licht, rijk textuurdetail, verticale 9:16 compositie",
    illustrated: "gedetailleerde donkere fantasy-illustratie, geschilderde texturen, dramatische schaduwen, verticale 9:16 compositie",
    manuscript: "middeleeuwse kroniek, inkttekeningen op verweerd perkament, rode en zwarte accenten, verticale 9:16 compositie",
    gothic: "gotische middeleeuwse horror, mist, kaarslicht, verweerde steen, dreigende sfeer, verticale 9:16 compositie"
  };
  const angleNames = {
    mystery: "bouw een mysterie op en onthul de kern pas aan het einde",
    character: "focus op motivatie, keuzes en gevolgen van het personage",
    timeline: "leg de gebeurtenis chronologisch en begrijpelijk uit",
    theory: "presenteer het als theorie, scheid aantoonbare feiten van speculatie",
    detail: "open met een opvallend detail en leg uit waarom het ertoe doet"
  };

  function safeText(value) {
    return String(value || "").trim();
  }
  function notify(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    window.setTimeout(() => toast.classList.remove("show"), 2100);
  }
  async function copyText(value) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(value);
      } else {
        const temp = document.createElement("textarea");
        temp.value = value;
        temp.style.position = "fixed";
        temp.style.opacity = "0";
        document.body.appendChild(temp);
        temp.select();
        const ok = document.execCommand("copy");
        temp.remove();
        if (!ok) throw new Error("Kopiëren niet beschikbaar");
      }
      notify("Gekopieerd naar klembord");
    } catch (_) {
      notify("Kopiëren lukte niet. Selecteer en kopieer de tekst handmatig.");
    }
  }
  function download(name, content, type) {
    const blob = new Blob([content], { type: type || "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function buildPrompt(data) {
    const facts = data.facts || "(Nog geen feiten toegevoegd. Vraag om een korte briefing en verzin geen specifieke feiten.)";
    return `Je bent een zorgvuldige schrijver van YouTube Shorts over ${data.universe}.
Maak een verticale video van ongeveer ${data.duration} seconden over: ${data.topic}

VERTELHOEK
${angleNames[data.angle]}

VASTE FEITEN EN NOTITIES VAN DE MAKER
${facts}

SCHRIJFREGELS
- Schrijf in natuurlijk, energiek Nederlands; begin met een sterke hook in de eerste 1-2 seconden.
- Richt op circa ${Math.round(Number(data.duration) * 2.3)} tot ${Math.round(Number(data.duration) * 2.7)} gesproken woorden; houd zinnen kort.
- Gebruik een duidelijke opbouw: hook, context, onthulling/inzicht, afsluitende vraag.
- Verzin geen citaten, gebeurtenissen, boekpassages of canonfeiten.
- Als een detail niet met de notities is te staven, markeer het als onzeker of laat het weg.
- Scheid boekcanon, tv-canon en fan-theorieën expliciet; ga niet stilzwijgend tussen versies wisselen.
- Citeer geen lange stukken uit de boeken en kopieer geen script/dialogen uit de serie.
- Geef output in deze volgorde:
  1. Titel (max. 70 tekens)
  2. Voice-overtekst, zonder tijdcodes
  3. Scèneplan met 4-6 scènes, elk met tijdsduur, beeldbeschrijving en tekst op scherm
  4. Eén beeldprompt per scène in deze stijl: ${styleNames[data.style]}
  5. Ondertiteltekst per scène
  6. Korte beschrijving en 5-8 relevante hashtags
  7. Een lijstje met beweringen die de maker nog moet controleren

VISUELE RICHTLIJNEN
Stijl: ${styleNames[data.style]}
- Houd uiterlijk, kleding, leeftijd, haar en kenmerkende attributen van personages consistent tussen scènes.
- Maak geen exacte kopie van een acteur of bestaande serie-screenshot; beschrijf een eigen, originele interpretatie.
- Geen logo's, watermerken of onleesbare tekst in gegenereerde beelden.
- Compositie moet werken op een telefoon in 9:16.`;
  }
  function makeMetadata(data) {
    const slug = data.topic.toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 24) || "westeroslore";
    return `${data.topic} | ${data.universe}\n\nKorte beschrijving:\nDuik in de lore van ${data.universe}. Feiten en interpretaties worden waar nodig apart gehouden.\n\n#GameOfThrones #HouseOfTheDragon #Westeros #ASOIAF #Lore #Shorts #Fantasy\n\nBestandslabel: ${slug}`;
  }
  function makeScenes(text, data) {
    const blocks = text.split(/\n\s*\n/).map(s => s.trim()).filter(Boolean);
    const lines = blocks.length > 1 ? blocks : text.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(Boolean);
    const count = Math.min(6, Math.max(1, lines.length));
    const duration = Number(data.duration) || 30;
    const per = duration / count;
    const target = $("scene-output");
    target.replaceChildren();
    lines.slice(0, 6).forEach((line, i) => {
      const start = Math.round(i * per);
      const end = Math.round((i + 1) * per);
      const card = document.createElement("article");
      card.className = "scene-card";
      const heading = document.createElement("h4");
      heading.textContent = `SCÈNE ${i + 1} · ${start}s–${end}s`;
      const body = document.createElement("p");
      body.textContent = line;
      const visual = document.createElement("p");
      visual.className = "visual";
      visual.textContent = `Beeldprompt: ${data.topic}; ${styleNames[data.style]}; passend bij deze voice-over: "${line.slice(0, 180)}". Geen tekst in beeld, verticale 9:16 compositie.`;
      card.append(heading, body, visual);
      target.appendChild(card);
    });
    if (lines.length > 6) {
      const note = document.createElement("p");
      note.className = "hint";
      note.textContent = "Er zijn meer dan 6 tekstblokken. Voor deze starter zijn de eerste 6 scènes getoond; combineer tekst waar nodig.";
      target.appendChild(note);
    }
    if (!text.trim()) notify("Plak eerst je voice-overtekst.");
  }
  function toSrt(text, duration) {
    const segments = text.split(/\n\s*\n/).map(s => s.trim()).filter(Boolean);
    const chunks = segments.length ? segments : text.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(Boolean);
    const total = Number(duration) || 30;
    const safeChunks = chunks.slice(0, 50);
    const stamp = (sec) => {
      const ms = Math.round((sec % 1) * 1000);
      const whole = Math.floor(sec);
      const h = Math.floor(whole / 3600);
      const m = Math.floor((whole % 3600) / 60);
      const s = whole % 60;
      return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")},${String(ms).padStart(3,"0")}`;
    };
    return safeChunks.map((chunk, i) => {
      const start = i * total / safeChunks.length;
      const end = (i + 1) * total / safeChunks.length;
      return `${i + 1}\n${stamp(start)} --> ${stamp(end)}\n${chunk.replace(/\s+/g, " ")}\n`;
    }).join("\n");
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = {
      topic: safeText($("topic").value),
      universe: $("universe").value,
      duration: $("duration").value,
      style: $("style").value,
      facts: safeText($("facts").value),
      angle: $("angle").value,
      createdAt: new Date().toISOString(),
      app: "Westeros Shorts Studio",
      version: "1.0"
    };
    if (!data.topic) { notify("Vul eerst een onderwerp in."); return; }
    project = data;
    $("prompt-output").value = buildPrompt(data);
    $("metadata-output").value = makeMetadata(data);
    $("script-input").value = "";
    $("scene-output").replaceChildren();
    $("srt-wrap").hidden = true;
    results.hidden = false;
    results.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  $("copy-prompt").addEventListener("click", () => copyText($("prompt-output").value));
  $("copy-script").addEventListener("click", () => copyText($("script-input").value));
  $("make-scenes").addEventListener("click", () => {
    const script = safeText($("script-input").value);
    if (!script) { notify("Plak eerst je voice-overtekst."); return; }
    makeScenes(script, project);
  });
  $("make-srt").addEventListener("click", () => {
    const script = safeText($("script-input").value);
    if (!script) { notify("Plak eerst je voice-overtekst."); return; }
    $("srt-output").value = toSrt(script, project.duration);
    $("srt-wrap").hidden = false;
    $("srt-wrap").scrollIntoView({ behavior: "smooth", block: "nearest" });
  });
  $("copy-srt").addEventListener("click", () => copyText($("srt-output").value));
  $("download-srt").addEventListener("click", () => download("ondertitels.srt", $("srt-output").value, "application/x-subrip;charset=utf-8"));
  $("copy-metadata").addEventListener("click", () => copyText($("metadata-output").value));
  $("download-project").addEventListener("click", () => {
    const output = { ...project, voiceover: safeText($("script-input").value), prompt: $("prompt-output").value, metadata: $("metadata-output").value, subtitles: $("srt-output").value || "" };
    download("westeros-shorts-project.json", JSON.stringify(output, null, 2), "application/json;charset=utf-8");
  });
  $("download-brief").addEventListener("click", () => {
    const content = `${$("prompt-output").value}\n\n--- SCRIPT ---\n${$("script-input").value}\n\n--- TITEL & HASHTAGS ---\n${$("metadata-output").value}`;
    download("westeros-shorts-briefing.txt", content, "text/plain;charset=utf-8");
  });
})();